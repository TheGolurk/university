package com.upemor;

public class TrianguloIsosceles extends Triangulo {


    public TrianguloIsosceles(double area, double altura, double base) {
        super(area, altura, base);
    }

    @Override
    public void ImprimirArea() {
        super.ImprimirArea();
    }

    @Override
    public void CalcularArea() {
        super.CalcularArea();
    }
}
