#!/bin/bash

gcc proyecto.c -o a.out && ./a.out
